[![solution](https://flat.badgen.net/badge/solution/available/green?icon=github)](webapp)
[![demo](https://flat.badgen.net/badge/demo/deployed/blue?icon=github)](https://sap-samples.github.io/ui5-mdc-json-tutorial/u1/ex0/dist)
# Exercise 0: Setup the Project on Your Machine

This exercise will guide you through the process of setting up a development environment. We will install Node.js, download and extract a zip file for a project, install project dependencies using npm, and serve the project using the UI5 tooling.

## Step 1: Install Node.js

If it is not already available, the first step is to download and install it from https://nodejs.org/.

We can confirm the installation by opening our terminal or command prompt and typing:

```bash
node -v
```

This command should display the installed version of Node.js.

## Step 2: Download and Extract Project Files

Next, we will download the project files contained in a .zip file.
- Download the project files from [mdc.tutorial.zip](https://sap-samples.github.io/ui5-mdc-json-tutorial/mdc.tutorial.zip).
- Once the download is complete, navigate to the download location and extract the .zip file.

## Step 3: Open the Project Folder

Now, we will open the project folder in our code editor.

- Navigate to the extracted project folder.
- Open the folder in our preferred code editor.

The structure should look like this:

![Alt text](u1/ex0_folder.png)

## Step 4: Install Project Dependencies

Once the project is open in our code editor, we will install the project dependencies using npm, the Node Package Manager, which was installed alongside Node.js.

- Open a terminal or command prompt in our project's root directory.
- Run the following command:

```bash
npm install
```

This command will read the `package.json` file in our project and install the necessary dependencies.

## Step 5: Serve the Project

Finally, we will serve the project using ui5.

- In the terminal or command prompt at our project's root directory, run the following command:

```bash
npm start
```

This command will start a development server for our project. You can access the development server at http://localhost:8080/index.html and check out the running application! 🚀

![Exercise 0 Result](u1/ex0.png)

## Summary
Congratulations, we have successfully set up our development environment and served our project!

Continue to - [Exercise 1](../u1/ex1/readme.md)
